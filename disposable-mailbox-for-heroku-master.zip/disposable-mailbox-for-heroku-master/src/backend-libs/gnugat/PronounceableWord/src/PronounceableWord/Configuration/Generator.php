<?php
class PronounceableWord_Configuration_Generator {
    public $maximumConsecutiveTypesAtTheBegining = 1;
    public $maximumConsecutiveTypesInTheWord = 2;
}
